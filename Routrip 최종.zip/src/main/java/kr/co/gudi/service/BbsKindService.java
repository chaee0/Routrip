package kr.co.gudi.service;

import org.springframework.stereotype.Service;

@Service
public class BbsKindService {

}
