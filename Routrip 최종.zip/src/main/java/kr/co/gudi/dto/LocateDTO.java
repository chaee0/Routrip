package kr.co.gudi.dto;

public class LocateDTO {
	
	private String loc_idx;
	private String loc_lat;
	private String loc_lon;
	private String loc_name;
	private String road_address;
	private String land_address;
	
	public String getLoc_idx() {
		return loc_idx;
	}
	public void setLoc_idx(String loc_idx) {
		this.loc_idx = loc_idx;
	}
	public String getLoc_lat() {
		return loc_lat;
	}
	public void setLoc_lat(String loc_lat) {
		this.loc_lat = loc_lat;
	}
	public String getLoc_lon() {
		return loc_lon;
	}
	public void setLoc_lon(String loc_lon) {
		this.loc_lon = loc_lon;
	}
	public String getLoc_name() {
		return loc_name;
	}
	public void setLoc_name(String loc_name) {
		this.loc_name = loc_name;
	}
	public String getRoad_address() {
		return road_address;
	}
	public void setRoad_address(String road_address) {
		this.road_address = road_address;
	}
	public String getLand_address() {
		return land_address;
	}
	public void setLand_address(String land_address) {
		this.land_address = land_address;
	}
	
	
	
}
