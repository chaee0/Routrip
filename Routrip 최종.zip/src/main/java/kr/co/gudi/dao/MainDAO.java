package kr.co.gudi.dao;

public interface MainDAO {

}
