package kr.co.gudi.dao;

import java.util.ArrayList;

import kr.co.gudi.dto.MapDTO;

public interface MapDAO {

	ArrayList<MapDTO> map();

}
